from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import winsound
import threading
import time

def start_main_page():
    def onclose():
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            xy.destroy()
        
    def start():
        xy.destroy()
        from option import sp2
        sp2.main()
        
    def admin():
        xy.destroy()
        from option import ad1
    
    winsound.PlaySound('MUSIC.wav', winsound.SND_ASYNC | winsound.SND_LOOP)    
##    global music_paused
##    music_paused==False
    ##file='MUSIC.wav'
    
##    def play():
##        if music_paused:
##            winsound.PlaySound('MUSIC.wav',winsound.SND_file | winsound.SND_LOOP | winsound.SND_ASYNC)
##            music_paused==False
##            button.config(text="Pause", bg="red")      
##        else:
##            winsound.PlaySound(None,winsound.SND_LOOP | winsound.SND_ASYNC)
##            music_paused == True
##            button.config(text="Play", bg="green")
        
    xy=Tk()
    xy.title('Build Name To Question Game')
    xy.geometry('700x500+200+90')
    xy.resizable(0,0)
    xy.configure(background='aqua')
    xy.protocol("WM_DELETE_WINDOW",onclose)
    music_paused = False

##    button = Button(xy, text="Play", width=10, command=play, bg="green", fg="black")
##    button.pack(side=LEFT)
    
    hea = Label(
            xy,
            text="Welcome to Build Name-word To Question Game",
            bg='#e6fff5',
            fg='#9e467f',
            wraplength=200,
            borderwidth=2,
            relief="solid",
            font=("Courier,Broadway", 28))
    hea.pack(side=TOP,pady=10)

    start_btn = Button(
        xy,
        text="Let's Go",
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        command=start
        )
    start_btn.pack(pady=(50, 20))

    Admin = Button(
        xy,
        text="ADMIN",
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        command=admin,
        )
    Admin.pack(pady=(50, 20))

    xy.mainloop()
    
start_main_page()
