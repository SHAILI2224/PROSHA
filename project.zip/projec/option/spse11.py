from tkinter import *

lm=Tk()
##lm.title('Setting page in Game')
##lm.geometry('100x300+250+150')
##lm.resizable(0,0)

def back():
    lm.destroy()
    import sp1
    sp1.start_main_page()

#im1=PhotoImage(file='back.png')
lab_img1 = Button(
    lm,
    text="HOME",
    #image=im1,
    bg='#e6fff5',
    border=0,
    justify='center',
    command=back,
    )
lab_img1.grid(row=0,column=0)

l1=Label(lm,text='Welcome to Settings',font=('Helvetica',16,'bold'),bg='black',fg='white')
l1.config(font=('Broadway 22'))
l1.grid(row=0,column=1,padx=70,pady=10)

lm.mainloop()
    
#setting ma maro vichar 6 menubar banavu setting ma Instruction & back nu button.
#back nu button banavu.Instruction ma 100 score thay pachi bonus level ramvu hoy
#to na ramvu hoy to 'no' aapi thakyou you play game & your game are complite
