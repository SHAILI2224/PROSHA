from tkinter import *
from tkinter import messagebox

def mainm4():
    xy=Tk()
    xy.title('Build Name To Question Game')
    xy.geometry('700x500+200+90')
    xy.resizable(0,0)
    xy.configure(background='aqua')
    
    #image set in label
    im1=PhotoImage(file='background.png')
    l1 = Label(xy,
               image=im1,
               bg='#e6fff5',
               border=15,
               justify='center')
    l1.grid(row=11,column=0, columnspan=100)

    def setting():
        xy.destroy()
        import sp1
        sp1.start_main_page()
    imm2 = PhotoImage(file='home.png')
    b=Button(xy,
             image=imm2,
             width=50,
             borderwidth=5,
             height=50,
             fg="#000000",
             bg="#99ffd6",
             font=("", 13),
             cursor="hand2",
             command=setting)
    b.grid(row=1,column=0,padx=10,pady=10)
    
    def score():
        xy.destroy()
        from option import spsc10
        spsc10.scsp()   
    b1=Button(xy,text='SCORE',width=18,
        borderwidth=5,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        command=score)
    b1.grid(row=1,column=1,padx=10,pady=10)
    
    def guest():
        xy.destroy()
        from option import spg9
    b2=Button(xy,text='GUEST',width=18,
        borderwidth=5,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        command=guest)
    b2.grid(row=1,column=2,padx=10,pady=10)

    
    def Regris():
        xy.destroy()
        from option import spre5
        spre5.regristation()
    im3 = PhotoImage(file='login.png')
    b3=Button(
        xy,
        image=im3,
        #text='LOGREGRI',
        width=50,
        height=50,
        borderwidth=5,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2"
        ,command=Regris)
    b3.grid(row=1,column=3,padx=10,pady=10)

    xy.mainloop()
mainm4()
