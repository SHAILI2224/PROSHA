from tkinter import *
import sqlite3

global sc

def start_main_page(uname):
    def start_game(args):
        main_window.destroy()
        if args == 1:
            from option import Animals
            Animals.main(uname)
        elif args == 2:
            from option import Body_parts
            Body_parts.main(uname)
        elif args == 3:
            from option import Colour
            Colour.main(uname)
        elif args == 4:
            from option import Fruit
            Fruit.main(uname)
        elif args == 5:
            from option import Shapes
            Shapes.main(uname)
        elif args == 6:
            from option import Vegetable
            Vegetable.main(uname)
        elif args == 7:
            from option import Vehicles
            Vehicles.main(uname)
        elif args == 8:
            from option import spg7
            spg7.gameg7(uname)
        elif args == 9:
            from option import spm4
            spm4.mainm4()
            
    global sc        
    conn=sqlite3.connect('users.db')
    cur= conn.cursor()
    
##        sc = score.cget("text")
##
##        cur.execute('SELECT * FROM scores ORDER BY score')
##        cur.fetchone()
    
    def option():
        ba=Button(
            main_window,
            #text='bac',
            image=img1,
            bg='#e6fff5',
            border=0,
            justify='center',
            command=lambda:start_game(9),
        )
        lab_img1 = Button(
            main_window,
            text="Select",
            bg='#e6fff5',
            border=0,
            justify='center',
            font=("Arial", 12)

        )
        sel_btn1 = Button(
            text="Animals",
            width=18,
            borderwidth=8,
            font=("", 18),
            fg="#000000",
            bg="#99ffd6",
            cursor="hand2",
            command=lambda: start_game(1),
        )

        sel_btn2 = Button(
            text="Body parts",
            width=18,
            borderwidth=8,
            font=("", 18),
            fg="#000000",
            bg="#99ffd6",
            cursor="hand2",
            command=lambda: start_game(2),
        )

        sel_btn3 = Button(
            text="Colour",
            width=18,
            borderwidth=8,
            font=("", 18),
            fg="#000000",
            bg="#99ffd6",
            cursor="hand2",
            command=lambda: start_game(3),
        )

        sel_btn4 = Button(
            text="Fruits",
            width=18,
            borderwidth=8,
            font=("", 18),
            fg="#000000",
            bg="#99ffd6",
            cursor="hand2",
            command=lambda: start_game(4),
        )

        sel_btn5 = Button(
            text="Shapes",
            width=18,
            borderwidth=8,
            font=("", 18),
            fg="#000000",
            bg="#99ffd6",
            cursor="hand2",
            command=lambda: start_game(5),
        )

        sel_btn6 = Button(
            text="Vegetable",
            width=18,
            borderwidth=8,
            font=("", 18),
            fg="#000000",
            bg="#99ffd6",
            cursor="hand2",
            command=lambda: start_game(6),
        )

        sel_btn7 = Button(
            text="Vehicles",
            width=18,
            borderwidth=8,
            font=("", 18),
            fg="#000000",
            bg="#99ffd6",
            cursor="hand2",
            command=lambda: start_game(7),
        )
        sel_btn8 = Button(
            text="General Knowledge",
            width=18,
            borderwidth=8,
            font=("", 18),
            fg="#000000",
            bg="#99ffd6",
            cursor="hand2",
            command=lambda: start_game(8),
        )
        ba.grid(row=0,column=0)
        lab_img1.grid(row=0, column=1, padx=20)
        sel_btn1.grid(row=0, column=6, pady=(10, 0), padx=50, )
        sel_btn2.grid(row=1, column=6, pady=(10, 0), padx=50, )
        sel_btn3.grid(row=2, column=6, pady=(10, 0), padx=50, )
        sel_btn4.grid(row=3, column=6, pady=(10, 0), padx=50, )
        sel_btn5.grid(row=4, column=6, pady=(10, 0), padx=50, )
        sel_btn6.grid(row=5, column=6, pady=(10, 0), padx=50, )
        sel_btn7.grid(row=6, column=6, pady=(10, 0), padx=50, )
        sel_btn8.grid(row=6, column=6, pady=(10, 0), padx=50, )


    def show_option():
        start_btn.destroy()
        BACKBU.destroy()
        lab_img.destroy()
        option()

    def back():
        main_window.destroy()
        from option import spm4
        spm4.mainm4()
    
    main_window = Tk()

    main_window.geometry("700x500+200+90")
    main_window.resizable(0, 0)
    main_window.title("Guess the Word")
    main_window.configure(background="#e6fff5")
    

    img1 = PhotoImage(file="back.png")
    BACKBU = Button(
        main_window,
        #text='bac',
        image=img1,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=back,
    )
    BACKBU.pack(side=TOP,anchor="nw", pady=10, padx=10)


    lab_img = Label(
        main_window,
        text=f"Guess the Word Game welcome {uname}",
        bg='#e6fff5',
        wraplength=500,
        font=("Courier", 28)
    )
    lab_img.pack(pady=(50, 0))

##    score = Label(
##        text="Score:- 0",
##        pady=10,
##        bg="#e6fff5",
##        fg="#000000",
##        font="Titillium  14 bold"
##    )
##    score.pack(pady=(50, 10))
##    
    start_btn = Button(
        main_window,
        text="Start",
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        command=show_option,
    )
    start_btn.pack(pady=(50, 20))

    main_window.mainloop()


#start_main_page()
