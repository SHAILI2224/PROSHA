from tkinter import *

def start_admin_page():
    xy=Tk()
    xy.title('Build Name To Question Game in ADMIN Module')
    xy.geometry('700x500+200+90')
    xy.resizable(0,0)
    xy.configure(background='OLIVE')

    def back():
        xy.destroy()
        import sp1
        sp1.start_main_page()

    
    img = PhotoImage(file='back.png')

    lab_img1 = Button(
        xy,
        #text='bac',
        image=img,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=back,
    )
    lab_img1.pack(anchor="nw",pady=10, padx=10)

    def ADD_USER():
        xy.destroy()
        from option import adure3
        adure3.regristation()
        
    ADD_USER = Button(
        xy,
        text="ADD USER",#regristation page connect
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        command=ADD_USER,
        )
    ADD_USER.pack(pady=(10, 20))
    
    def DELETE_USER():
        xy.destroy()
        from option import deleteu4
        deleteu4.login()
    
    DELETE_USER = Button(
        xy,
        text="DELETE USER",# make a query in other,re,login page or repage
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        command=DELETE_USER,
        )
    DELETE_USER.pack(pady=(20, 20))

    def ADD_PAGE():
        from option import spgb8
        
    ADD_PAGE = Button(
        xy,
        text="ADD PAGE",  #game page
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        )
    ADD_PAGE.pack(pady=(20, 20))

    def ADD_GUEST():
        xy.destroy()
        from option import adgu5
        adgu5.guest()
    ADD_GUEST = Button(
        xy,
        text="ADD GUEST",#regristation page connect
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        command=ADD_GUEST,
        )
    ADD_GUEST.pack(pady=(10, 20))

    def DELETE_GUEST():
        xy.destroy()
        from option import addelgu6
        addelgu6.guest()
    DELETE_GUEST = Button(
        xy,
        text="DELETE GUEST",# make a query in other,re,login page or repage
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        cursor="hand2",
        command=DELETE_GUEST,
        )
    DELETE_GUEST.pack(pady=(20, 20))

    xy.mainloop()
    
start_admin_page()
