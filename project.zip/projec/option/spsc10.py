from tkinter import *
from tkinter import ttk
import tkinter as tk
import sqlite3

def scsp():
    def back():
        kl.destroy()
        from option import spm4
        spm4.mainm4()

    def GUEST_score():
        for gucl in tree.get_children():
            tree.delete(gucl)
        for row in conn.execute('SELECT * FROM guest_score ORDER BY score DESC LIMIT 10'):
            tree.insert("","end",text="1",values=(row))

    def USER_score():
        for cl in tree.get_children():
            tree.delete(cl)
        for i in conn.execute('SELECT * FROM scores ORDER BY score DESC LIMIT 10'):
            tree.insert("","end",text="1",values=(i))
       
    conn=sqlite3.connect('users.db')
    cur= conn.cursor()

    kl=Tk()
    kl.title('Score page in show')
    kl.geometry('700x500+200+90')
    kl.resizable(0,0)
    kl.configure(bg="#87567a")
        
    IMA1 = PhotoImage(file='back.png')
    b1=Button(kl,image=IMA1,command=back)#text='back'
    b1.pack(anchor="nw",padx=10,pady=10)

    l1=Label(kl,text='Welcome to Score show',font=('Helvetica',16,'bold'),fg='green')
    l1.config(font=('Broadway 22'))
    l1.pack(anchor=CENTER,padx=50)
        
    GUEST = Button(
        kl,
        width=18,
        borderwidth=8,
        font=("", 13),
        fg="#000000",
        bg="#99ffd6",
        text='GUEST SCORE',
        command=GUEST_score
    )
    GUEST.pack(anchor='nw',fill='x',expand=True)

    USER = Button(
        kl,
        width=18,
        borderwidth=8,
        font=("", 13),
        fg="#000000",
        bg="#99ffd6",
        text='USER SCORE',
        command=USER_score
    )
    USER.pack(anchor='ne',fill='x',expand=True)
    
    style=ttk.Style(kl)
    style.theme_use('clam')
    style.configure("table",background='yellow')

    tree=ttk.Treeview(kl,column=('ID','NAME','SCORE'),show='headings',height=15)

    tree.column('#1',anchor=CENTER)
    tree.heading('#1',text='ID')

    tree.column('#2',anchor=CENTER)
    tree.heading('#2',text='NAME')

    tree.column('#3',anchor=CENTER)
    tree.heading('#3',text='SCORE')

    tree.pack(side=BOTTOM,anchor='s',fill='x')

    kl.mainloop()
scsp()
