from tkinter import *
from tkinter import messagebox
import sqlite3

def guest():
    jk=Tk()
    jk.title('Guest page in Game')
    jk.geometry('700x500+200+90')
    jk.resizable(0,0)
    jk.config(bg='#4c6478')

    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS guest (name TEXT primary key, password TEXT)")

    def back():
        jk.destroy()
        from option import spm4
        spm4.mainm4()

    def validate_insert():
        name = username_entry.get()
        password = password_entry.get()
        try:
            if validate_data(name, password):
                cur.execute("INSERT INTO guest VALUES (?,?)", (name, password))                
                messagebox.showinfo("Login Success", "Welcome Guest "+name+" registered successfully")
                clear_data()
            else:
                messagebox.showerror("Error", "Invalid input")
        except sqlite3.IntegrityError:
            messagebox.showerror("Error","Guest with the same name already exists!")
        conn.commit()

    def validate_login():
        name = username_entry.get()
        password = password_entry.get()
        cur.execute("SELECT * FROM guest WHERE name = ? AND password = ? ", (name, password))
        result = cur.fetchone()

        if result is not None:
            messagebox.showinfo("Login Successful",'Welcome,'+name+'!')
            jk.destroy()
            from option import guesco12
            guesco12.gameguest(name)
        else:
            messagebox.showerror("Login Failed",'Invalid username or password')
        conn.commit()
        
    def validate_data(name, password):
        if name == "" or any(char.isdigit() for char in name):
            messagebox.showerror("Error", "Invalid name.only character allowed")
            return False
        if password == "" or len(password) < 8:
            messagebox.showerror("Error", " Invalid Password.you must enter  at least 8 range")
            return False
        return True
    
    def clear_data():
        username_entry.delete(0,END)
        password_entry.delete(0,END)
    
    def toggle_password():
        if password_entry.cget("show") == "":
            password_entry.config(show="*")
        else:
            password_entry.config(show="")

    IMB=PhotoImage(file='back.png')
    B1=Button(jk,image=IMB,bg='#e6fff5',border=0,justify="center",command=back)
    B1.grid(row=0,column=0,padx=5,pady=5)

    l1=Label(jk,text='Welcome to Guest form',font=('Helvetica',16,'bold'),bg='yellow',fg='black')
    l1.config(font=('Broadway 22'))
    l1.grid(row=0,column=1,padx=10,pady=10)

    username_label = Label(jk, text="Username:")
    username_label.grid(row=2,column=1,pady=10, padx=10)
    username_entry = Entry(jk)
    username_entry.grid(row=3,column=1,pady=10, padx=10)

    password_label = Label(jk, text="Password:")
    password_label.grid(row=4,column=1,pady=10, padx=10)
    password_entry = Entry(jk, show="*")# Show asterisks for password
    password_entry.grid(row=5,column=1,pady=10, padx=10)

    checkbutton = Checkbutton(jk, text="Show password", command=toggle_password)
    checkbutton.grid(row=6,column=1,pady=10, padx=10)

    login_button = Button(jk, text="Sign up",command=validate_insert)
    login_button.grid(row=7,column=1,pady=10, padx=10)

    login = Button(jk, text="Login_play",command=validate_login)
    login.grid(row=8,column=1,padx=5,pady=2)

    jk.mainloop()
guest()
