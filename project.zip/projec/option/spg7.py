from tkinter import *
from random import *
from tkinter import messagebox
import time
import sqlite3

QU1=['In C++ Language what is use to same as Printf()?',
     'which American poet,writer is born January 19, 1809?', 
     'who is the Queen of the Boxing?',
     'who is the King of Guitar?',
     'What is HIDE word Synonym?',
     'What is the longest river in the world?',
     'What is full form ABI?',
     'What is full form API?',
     'Who is the father of computer',
     'IBM Stands for...',
     'CPU stands for...',
     'HTML stands for...',
     'DNS stands for...',
     'RAM stands for...',
     'What is capital city of Australia?',
     'What is chemical symbol for Gold?',
     'Who painted the Mona Lisa?',
     'What is currency of Japan?',
     'In What year did Titanic sink?',
     'What is the tallest mountain in the world?',
     'What is the chemical symbol for Water?',]

words1 = ['cout',
          'Edgar Allan Poe',
          'MC Mary Kom',
          'Jimi Hendrix',
          'camouflage',
          'The Nile',
          'Application Binary Interface',
          'Application Programming Interface',
          'Charles Babbage',
          'International Business Mechines',
          'Central Processing Unit',
          'HyperText Markup Language',
          'Domain Name System',
          'Random Access Memory',
          'Canberra',
          'Au',
          'Leonardo da Vinci',
          'Yen',
          '1912',
          'Mount Everest',
          'H2O',]

ran_num = randrange(0, (len(QU1)))
jumbled_rand_word = QU1[ran_num]

global points,nm,sc
points = 0

def gameg7(uname):
    def back():
        gh.destroy()
        from option import spm4
        spm4.mainm4()

    def change():
        global ran_num
        ran_num=randrange(0,(len(QU1)))
        word.configure(text=QU1[ran_num])
        E1.delete(0,END)
        answ.configure(text="")
        
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS scores (id INTEGER PRIMARY KEY AUTOINCREMENT,uname TEXT, score INTEGER, FOREIGN KEY (uname) REFERENCES userre (name))")

    def check():
        global points,ran_num,nm,sc
        user_word=E1.get()
        nm = name_label.cget("text")
        sc = score.cget("text")

        # Check if the player's name exists in the database
        cur.execute("SELECT score FROM scores WHERE uname = ?", (nm,))
        existing_record = cur.fetchone()

        if existing_record:
            # Update the existing record
            cur.execute("UPDATE scores SET score = ? WHERE uname = ?", (points, nm))
        else:
            # Insert a new record
            cur.execute("INSERT INTO scores (uname, score) VALUES (?, ?)", (nm, sc))

        conn.commit()
        if E1.get()=="":
            messagebox.showerror("Error", "you must enter the answer!")
        else:
            if user_word == words1[ran_num]:
                points += 5
                score.configure(text="Score:- " + str(points))
                messagebox.showinfo('correct', "Correct Answer.. Keep it Up!")
                ran_num = randrange(0, (len(QU1)))
                word.configure(text=QU1[ran_num])
                E1.delete(0, END)
                answ.configure(text="")
                if points >= 100:
                    mess=messagebox.askquestion('play game','Are you play bonus game')
                    if mess == 'yes':
                        gh.destroy()
                        from option import spgb8
    ##                #spm4.mainm4()
                    else:
                        messagebox.showinfo('finish game','Your game is Finish')
                        gh.destroy()
                        import sp1
                else:
                    answ.configure(text='you have do more score')
            else:
                messagebox.showerror("Error", "Inorrect Answer..Try your best!")
                E1.delete(0, END)
        
    def show_answer():
        global points,nm,sc
        if points > 4:
            points -= 5
            score.configure(text="Score: " + str(points))
            time.sleep(0.5)
            answ.configure(text=words1[ran_num])
        else:
            answ.configure(text='Not enough points')
        nm = name_label.cget("text")
        sc = score.cget("text")

        # Check if the player's name exists in the database
        cur.execute("SELECT score FROM scores WHERE uname = ?", (nm,))
        existing_record = cur.fetchone()

        if existing_record:
            # Update the existing record
            cur.execute("UPDATE scores SET score = ? WHERE uname = ?", (points, nm))
        else:
            # Insert a new record
            cur.execute("INSERT INTO scores (uname, score) VALUES (?, ?)", (nm, sc))

        conn.commit()
    
    gh=Tk()
    gh.title('Build Name To Question Game')
    gh.geometry('700x500+200+90')
    gh.resizable(0,0)
    gh.configure(background="#e6fff5")
    
    img1 = PhotoImage(file="back.png")
    lab_img1 = Button(
        gh,
        #text='bac',
        image=img1,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=back,
    )
    lab_img1.pack(anchor='nw', pady=10, padx=10)

    name_label = Label(gh, text=f"Name: {uname}", font=("Arial", 12))
    name_label.pack(pady=10)

    l1= Label(gh,text='Best of Luck!',bg="#e6fff5",fg="#00ff00",font="Titillium  14 bold")
    l1.pack(side=TOP)

    score = Label(
        text="Score:- 0",
        pady=2,
        bg="#e6fff5",
        fg="#000000",
        font="Titillium  14 bold"
    )
    score.pack(anchor="n")

    word = Label(
        text=jumbled_rand_word,
        pady=10,
        bg="#e6fff5",
        fg="#000000",
        font="Titillium  14 bold"
    )
    word.pack()

    E1 = Entry(
        font="none 26 bold",
        borderwidth=10,
        justify='center',
    )
    E1.pack()

    submit = Button(
        text="Submit",
        width=18,
        borderwidth=8,
        font=("", 13),
        fg="#000000",
        bg="#99ffd6",
        command=check
    )
    submit.pack(pady=(10,20))

    change = Button(
        text="Change Questation",
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        command=change,
    )
    change.pack()

    ans = Button(
        text="Answer",
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        command=show_answer,
    )
    ans.pack(pady=(20,10))

    answ = Label(
        text="",
        bg="#e6fff5",
        fg="#000000",
        font="Courier 15 bold",
    )
    answ.pack()

    gh.mainloop()
#gameg7()
