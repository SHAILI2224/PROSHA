from tkinter import *
import tkinter as tk
from tkinter import messagebox
import sqlite3

def adwelcome():
    root = tk.Tk()
    root.title("Admin Login")
    root.geometry('700x500+200+90')
    root.config(bg='#629682')
    
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS admin (name TEXT, password TEXT)")

    def back():
        root.destroy()
        import sp1
        sp1.start_main_page()
        
    im1=PhotoImage(file='back.png')
    lab_img1 = Button(
        root,
        #text='bac',
        image=im1,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=back,
    )
    lab_img1.pack(anchor='nw')
    def validate_admin():
        entered_name = name_entry.get()
        entered_password = password_entry.get()

        if entered_name == "admin" and entered_password == "123":
            # Show the ad2page (you can replace this with your actual page)
            cur.execute("INSERT INTO admin (name,password) VALUES (?,?)", (entered_name,entered_password ))
            conn.commit()
 
            messagebox.showinfo("Success", "Welcome, Admin!")
            root.destroy()
            from option import ad2
        else:
            messagebox.showerror("Error", "Invalid credentials. Please try again.")

    def toggle_password():
        if password_entry.cget("show") == "":
            password_entry.config(show="*")
        else:
            password_entry.config(show="")
    
    # Create the main window
    # Entry fields for name and password
    name_label = tk.Label(root, text="Name:")
    name_label.pack(pady=5)
    name_entry = tk.Entry(root)
    name_entry.pack(pady=5)

    password_label = tk.Label(root, text="Password:")
    password_label.pack(pady=5)
    password_entry = tk.Entry(root, show="*")  # Mask the password
    password_entry.pack(pady=5)

    checkbutton = Checkbutton(root, text="Show password", command=toggle_password)
    checkbutton.pack(pady=5)
    
    # Admin button
    admin_button = tk.Button(root, text="WELCOME_Admin", command=validate_admin)
    admin_button.pack(pady=5)

    root.mainloop()
adwelcome()
