from tkinter import *
from tkinter import messagebox
import sqlite3

def login():
    fg = Tk()
    fg.title("Login Form")
    fg.geometry("700x500+200+90")
    fg.resizable(0,0)
    fg.configure(bg="light blue")

    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS userlog (name TEXT, password TEXT)")

    def validate_login():
        uname = username_entry.get()
        password = password_entry.get()
        cur.execute("SELECT * FROM userre WHERE name = ? AND password = ? ", (uname, password))
        result = cur.fetchone()

        if result is not None:
            messagebox.showinfo("Login Successful",'Welcome,'+uname+'!')
            fg.destroy()
            from option import index
            index.start_main_page(uname)
        else:
            messagebox.showerror("Login Failed",'Invalid username or password')
        conn.commit()

    def toggle_password():
        if password_entry.cget("show") == "":
            password_entry.config(show="*")
        else:
            password_entry.config(show="")
            
    def back():
        fg.destroy()
        from option import spre5
        spre5.regristation()
        
    img1 = PhotoImage(file="back.png")
    lab_img1 = Button(
        fg,
        #text='bac',
        image=img1,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=back,
        )
    lab_img1.grid(row=0,column=0,pady=10, padx=10)
    
    l1=Label(fg,text='Welcome to Login form',font=('Helvetica',16,'bold'))
    l1.config(font=('Broadway 22'))
    l1.grid(row=0,column=1,padx=50,pady=20)

    username_label = Label(fg, text="Username:")
    username_label.grid(row=1,column=1,padx=5,pady=2)
    username_entry = Entry(fg)
    username_entry.grid(row=2,column=1,padx=5,pady=2)

    password_label = Label(fg, text="Password:")
    password_label.grid(row=3,column=1,padx=5,pady=2)
    password_entry = Entry(fg, show="*")    # Show asterisks for password
    password_entry.grid(row=4,column=1,padx=5,pady=2)

    checkbutton = Checkbutton(fg, text="Show password", command=toggle_password)
    checkbutton.grid(row=5,column=1,padx=5,pady=2)

    login_button = Button(fg, text="Login_play",command=validate_login)
    login_button.grid(row=6,column=1,padx=5,pady=2)

    fg.mainloop()
login()
