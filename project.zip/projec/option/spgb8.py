from tkinter import *

def back():
    import sp1
    sp1.start_main_page()
    
hi=Tk()
hi.title('BONUS Game')
hi.geometry('700x500+200+90')
hi.resizable(0,0)
    
im1=PhotoImage(file='back.png')
ba_bu=Button(
    hi,
    image=im1,
    bg='#e6fff5',
    border=0,
    justify='center',
    )
ba_bu.grid(row=0,column=0,padx=10,pady=10)

l1=Label(hi,text='Welcome to Bonus Level',font=('Helvetica',16,'bold'))
l1.config(font=('Broadway 22'))
l1.grid(row=0,column=1,padx=50,pady=20)

hi.mainloop()
