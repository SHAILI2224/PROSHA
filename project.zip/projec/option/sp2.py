from tkinter import *

def main():
    def logo():
        ab.destroy()
        from option import sp3
        sp3.main1()
        
    def back():
        ab.destroy()
        import sp1
        sp1.start_main_page()
    
    ab=Tk()
    ab.title('Build Name To Question Game with logo')
    ab.geometry('700x500+200+90')
    ab.resizable(0,0)
    ab.configure(background='#ADD8E6')
    ime=PhotoImage(file='logo.png')
    img1 = PhotoImage(file="back.png")

    lab_img1 = Button(
        ab,
        image=img1,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=back,
    )
    lab_img1.pack(anchor='nw', pady=10, padx=10)

    lab_img1 = Button(
        ab,
        image=ime,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=logo)
    lab_img1.pack(anchor='nw', pady=10, padx=120)

    ab.mainloop()
main()
