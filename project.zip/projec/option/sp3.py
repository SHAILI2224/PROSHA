from tkinter import *
from random import *
from tkinter import messagebox
import time

QU1=['What is HIDE word Synonym?',
     'What is full form ABI?',
     'What is full form API?']

words1 = ['camouflage',
          'Application Binary Interface',
          'Application Programming Interface']

ran_num = randrange(0, (len(QU1)))
jumbled_rand_word = QU1[ran_num]

global points
points = 0

def main1():
    def back():
        cd.destroy()
        import sp1
        sp1.start_main_page()

    def change():
        global ran_num
        ran_num=randrange(0,(len(QU1)))
        word.configure(text=QU1[ran_num])
        E1.delete(0,END)
        answ.configure(text="")

    def check():
        global points,ran_num
        user_word=E1.get()
        #E1.get(char.isalpha() or char.isdigit())
        if E1.get()=="":
            messagebox.showerror("Error", "you must enter the answer!")
        else:
            if user_word == words1[ran_num]:
                points += 5
                score.configure(text="Score:- " + str(points))
                messagebox.showinfo('correct', "Correct Answer.. Keep it Up!")
                ran_num = randrange(0, (len(QU1)))
                word.configure(text=QU1[ran_num])
                E1.delete(0, END)
                answ.configure(text="")
                nex(check)
            else:
                messagebox.showerror("Error", "Inorrect Answer..Try your best!")
                E1.delete(0, END)
        
    def nex(check):
        if points >= 10:
            mess=messagebox.askquestion('play game','Are you continue play game')
            if mess == 'yes':
                cd.destroy()
                from option import spm4
                spm4.mainm4()
            else:
                cd.destroy()
                import sp1
                sp1.start_main_page()
        else:
            answ.configure(text='you have do more score')

    def show_answer():
        global points
        if points > 4:
            points -= 5
            score.configure(text="Score: " + str(points))
            time.sleep(0.5)
            answ.configure(text=words1[ran_num])
        else:
            answ.configure(text='Not enough points')

    cd=Tk()
    cd.title('Level page')
    cd.geometry('700x500+200+90')
    cd.resizable(0,0)
    cd.configure(background="#e6fff5")
    img1 = PhotoImage(file="back.png")

    lab_img1 = Button(
        cd,
        image=img1,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=back
    )
    lab_img1.pack(anchor='nw', pady=10, padx=10)

    l1= Label(cd,text='Best of Luck!',bg="#e6fff5",fg="#00ff00",font="Titillium  14 bold")
    l1.pack(side=TOP)

    score = Label(
        text="Score:- 0",
        pady=2,
        bg="#e6fff5",
        fg="#000000",
        font="Titillium  14 bold"
    )
    score.pack(anchor="n")

    word = Label(
        text=jumbled_rand_word,
        pady=10,
        bg="#e6fff5",
        fg="#000000",
        font="Titillium  14 bold"
    )
    word.pack()

    E1 = Entry(
        font="none 26 bold",
        borderwidth=10,
        justify='center',
    )
    E1.pack()

    submit = Button(
        text="Submit",
        width=18,
        borderwidth=8,
        font=("", 13),
        fg="#000000",
        bg="#99ffd6",
        command=check)
    submit.pack(pady=(10,20))

    change = Button(
        text="Change Questation",
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        command=change)
    change.pack()

    ans = Button(
        text="Answer",
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        command=show_answer)
    ans.pack(pady=(20,10))

    answ = Label(
        text="",
        bg="#e6fff5",
        fg="#000000",
        font="Courier 15 bold",
    )
    answ.pack()
    cd.mainloop()
main1()
