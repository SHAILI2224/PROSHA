from tkinter import *
from tkinter import messagebox
import sqlite3
    
def regristation():
    ef = Tk()
    ef.title("Registration Form")
    ef.geometry("700x500+200+90")
    ef.resizable(0,0)
    ef.configure(bg="light blue")

    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS userre (name TEXT PRIMARY KEY, city TEXT, password TEXT, mobile TEXT, age INTEGER)")

    l1=Label(ef,text='Welcome to Regristation form',font=('Helvetica',16,'bold'))
    l1.config(font=('Broadway 22'))
    l1.grid(row=0,column=1,padx=50,pady=20)

    def back():
        ef.destroy()
        from option import spm4
        spm4.mainm4()
    
    img = PhotoImage(file='back.png')

    lab_img1 = Button(
        ef,
        #text='bac',
        image=img,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=back,
    )
    lab_img1.grid(row=0,column=0,pady=10, padx=10)

    def insert_data():
        name = name_entry.get()
        city = city_entry.get()
        password = password_entry.get()
        mobile = mobile_entry.get()
        age = age_entry.get()
        
        try:
            if validate_data(name, city, password, mobile, age):
                cur.execute("INSERT INTO userre VALUES (?,?,?,?,?)", (name, city, password, mobile, age))
                conn.commit()
                messagebox.showinfo("Success", "User registered successfully")
                clear_data()
            else:
                messagebox.showerror("Error", "Invalid input")
        except sqlite3.IntegrityError:
            messagebox.showerror("Error","User with the same name already exists!")
    
    def validate_data(name, city, password, mobile, age):
        if name == "" or any(char.isdigit() for char in name):
            messagebox.showerror("Error", "Invalid name.only character allowed")
            return False
        if city == "" or any(char.isdigit() for char in city):
            messagebox.showerror("Error", "Invalid city.only character allowed")
            return False
        if password == "" or len(password) < 8:
            messagebox.showerror("Error", " Invalid Password.you must enter  at least 8 range")
            return False
        if mobile == "" or len(mobile) != 10 or not mobile.isdigit():
            messagebox.showerror("Error", "Invalid mobile.Only 10 digit allowed")
            return False
        try:
            age = int(age)
            if age <= 0:
                messagebox.showerror("Error", "Invalid age")
                return False
        except ValueError:
            messagebox.showerror("Error", "Invalid age")
            return False
        return True

    def clear_data():
        name_entry.delete(0, END)
        city_entry.delete(0, END)
        password_entry.delete(0, END)
        mobile_entry.delete(0, END)
        age_entry.delete(0, END)

    def toggle_password():
        if password_entry.cget("show") == "":
            password_entry.config(show="*")
        else:
            password_entry.config(show="")

    def login_page():
        ef.destroy()
        from option import splo6
        splo6.login()

    name_label = Label(ef, text="Name:", bg="light blue")
    name_entry = Entry(ef)
    city_label = Label(ef, text="City:", bg="light blue")
    city_entry = Entry(ef)
    password_label = Label(ef, text="Password:", bg="light blue")
    password_entry = Entry(ef, show="*")
    checkbutton = Checkbutton(ef, text="Show password", command=toggle_password)
    checkbutton.place(relx=0.4,rely=0.4)
    mobile_label = Label(ef, text="Mobile:", bg="light blue")
    mobile_entry = Entry(ef)
    age_label = Label(ef, text="Age:", bg="light blue")
    age_entry = Entry(ef)
    b1= Button(ef, text="Submit", command=insert_data)
    b2 = Button(ef, text="Clear", command=clear_data)
    b3 = Button(ef, text="Alredy have an account",command=login_page)
    #b4 = Button(ef, text="Update",command=)

    name_label.place(relx=0.1,rely=0.2)
    name_entry.place(relx=0.2,rely=0.2)
    city_label.place(relx=0.1,rely=0.3)
    city_entry.place(relx=0.2,rely=0.3)
    password_label.place(relx=0.1,rely=0.4)
    password_entry.place(relx=0.2,rely=0.4)
    mobile_label.place(relx=0.1,rely=0.5)
    mobile_entry.place(relx=0.2,rely=0.5)
    age_label.place(relx=0.1,rely=0.6)
    age_entry.place(relx=0.2,rely=0.6)
    
    b1.place(relx=0.1,rely=0.7)
    b2.place(relx=0.2,rely=0.7)
    b3.place(relx=0.3,rely=0.7)

    ef.mainloop()
    
regristation()
