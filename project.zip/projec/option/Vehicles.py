from tkinter import *
from random import *
from tkinter import messagebox
import time
import sqlite3

VEHICLES_WORD = ['RIHLPOEETC', 'NELAARIP', 'CKTREO', 'LITSAOBA', 'UIECRS PIHS', 'ROAGC SPHI', 'TJE SKI', 'PIREAT IHSP',
                 'TBOA', 'SHIP', 'RUISAEMNB', 'IYLCECB', 'CAR', 'BUS', 'TIANR', 'UTKCR', 'NVA', 'LRTOMCCYEO', ]

VEHICLES_ANSWER = ['HELICOPTER', 'AIRPLANE', 'ROCKET', 'SAILBOAT', 'CRUISE SHIP', 'CARGO SHIP', 'JET SKI',
                   'PIRATE SHIP', 'BOAT', 'SHIP', 'SUBMARINE', 'BICYCLE', 'CAR', 'BUS', 'TRAIN', 'TRUCK', 'VAN',
                   'MOTORCYCLE', ]

ran_num = randrange(0, (len(VEHICLES_WORD)))
jumbled_rand_word = VEHICLES_WORD[ran_num]

global points,nm,sc
points = 0

def main(uname):
    def back():
        my_window.destroy()
        from option import index
        index.start_main_page(uname)

    def change():
        global ran_num
        ran_num = randrange(0, (len(VEHICLES_WORD)))
        word.configure(text=VEHICLES_WORD[ran_num])
        get_input.delete(0, END)
        ans_lab.configure(text="")

    def cheak():
        global points, ran_num
        user_word = get_input.get().upper()
        nm = name_label.cget("text")
        sc = score.cget("text")

        cur.execute("SELECT score FROM scores WHERE uname = ?", (nm,))
        existing_record = cur.fetchone()

        if existing_record:
           cur.execute("UPDATE scores SET score = ? WHERE uname = ?", (points, nm))
        else:
            cur.execute("INSERT INTO scores (uname, score) VALUES (?, ?)", (nm, sc))

        conn.commit()
        if get_input == "":
            messagebox.showerror("Error", "you must enter the answer!")
        else:
            if user_word == VEHICLES_ANSWER[ran_num]:
                points += 5
                score.configure(text="Score: " + str(points))
                messagebox.showinfo('correct', "Correct Answer.. Keep it Up!")
                ran_num = randrange(0, (len(VEHICLES_WORD)))
                word.configure(text=VEHICLES_WORD[ran_num])
                get_input.delete(0, END)
                ans_lab.configure(text="")
                if points >= 100:
                    mess=messagebox.askquestion('play game','Are you play bonus game')
                    if mess == 'yes':
                        my_window.destroy()
                        from option import spg7
                        spg7.gameg7(uname)
                    else:
                        messagebox.showinfo('finish game','Your game is Finish')
                        my_window.destroy()
                        import sp1
                else:
                    ans_lab.configure(text='you have do more score')
            else:
                messagebox.showerror("Error", "Inorrect Answer..Try your best!")
                get_input.delete(0, END)

    def show_answer():
        global points
        if points > 4:
            points -= 5
            score.configure(text="Score: " + str(points))
            time.sleep(0.5)
            ans_lab.configure(text=VEHICLES_ANSWER[ran_num])
        else:
            ans_lab.configure(text='Not enough points')

    my_window = Tk()
    my_window.geometry("700x500+200+90")
    my_window.resizable(0, 0)
    my_window.title("Guess the Word Game")
    my_window.configure(background="#e6fff5")
    img1 = PhotoImage(file="back.png")

    lab_img1 = Button(
        my_window,
        image=img1,
        bg='#e6fff5',
        border=0,
        justify='center',
        command=back,
    )
    lab_img1.pack(anchor='nw', pady=10, padx=10)

    name_label = Label(my_window, text=f"Name: {uname}", font=("Arial", 12))
    name_label.pack()

    l1= Label(my_window,text='Best of Luck!',bg="#e6fff5",fg="#00ff00",font="Titillium  14 bold")
    l1.pack(side=TOP)
    
    score = Label(
        text="Score:- 0",
        pady=10,
        bg="#e6fff5",
        fg="#000000",
        font="Titillium  14 bold"
    )
    score.pack(anchor="n")

    word = Label(
        text=jumbled_rand_word,
        pady=10,
        bg="#e6fff5",
        fg="#000000",
        font="Titillium  14 bold"
    )
    word.pack()

    get_input = Entry(
        font="none 26 bold",
        borderwidth=10,
        justify='center',
    )
    get_input.pack()

    submit = Button(
        text="Submit",
        width=18,
        borderwidth=8,
        font=("", 13),
        fg="#000000",
        bg="#99ffd6",
        command=cheak,
    )
    submit.pack(pady=(10, 20))

    change = Button(
        text="Change Word",
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        command=change,
    )
    change.pack()

    ans = Button(
        text="Answer",
        width=18,
        borderwidth=8,
        fg="#000000",
        bg="#99ffd6",
        font=("", 13),
        command=show_answer,
    )
    ans.pack(pady=(20, 10))

    ans_lab = Label(
        text="",
        bg="#e6fff5",
        fg="#000000",
        font="Courier 15 bold",
    )
    ans_lab.pack()

    my_window.mainloop()
