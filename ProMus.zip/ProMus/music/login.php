<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>login</title>
<link href="regist.css" rel="stylesheet" type="text/css" />
</head>

<body bgcolor="#33CC66">

<div align="center" class="bu"> Welcome To Our Music World </div>

<table width="954" align="center" border="1" class="su">
  <tr>
    <td width="146" align="center"><a href="img-profile.php">Home</a></div></td>
    <td width="146" align="center"><a href="regitra.php">Regristation</a></div></td>
    <td width="146" align="center"><a href="select.php">Select</a></div></td>
	<td width="146" align="center">Log in</td>
	<td width="146" align="center"><a href="contact.php"> Contact Us</a></td>
  </tr>
</table>

<h1 align="center">Login</h1>
<form action="login.php" method="post" enctype="multipart/form-data" name="login" target="_self">
<br><label>User_name-</label>
<input name="User_name" type="text" maxlength="30" required/>
  <br/>
  <br><label>Password</label>
      <input name="Password" type="password" maxlength="15" required/> <br />
        <div align="center">
        <input name="submit" type="submit" class="su" value="OK"/>
		</div>
</form>
</body>
<?php 
	if(isset($_POST['OK']))
	{
	
      $dbhost="localhost";
	  $dbname="music_world";
	  $dbusername="root";
	  $dbpassword="";
	  $msg="";
	  
	  $Enter_Name=$_POST['Enter_Name'];
	  $Password=$_POST['Password'];
	  
	if(!empty($Enter_Name) || !empty($Password))
	 {		
	  $conn=new mysqli($host,$dbusername,$dbpassword, $dbname);
	    if(mysqli_connect_error())
		{
	  die('connection failed Error('. mysqli_connect_error().')'. mysqli_connect_error());
	  	}
	    else
		{
		$select="SELECT * FROM `regristation` WHERE `User Name``Password`";
		 	$sql = "INSERT INTO `login` (`Id`, `User_Name`, `Password`) VALUES ('','$User_Name','$Password')";
			 $stmt = $conn->query($SELECT);	    
			$rnum = $stmt->num_rows;
			if ($rnum==0) 
			{
				$conn->query($sql);
				echo $msg="login successfully...";
			}
			else
			{
		 		echo $msg="Someone already login using this password";
			}
		 }
	}
	else{echo "All field are required";
	  die();}  
}?>
</html>