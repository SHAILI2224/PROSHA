	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
    <style type="text/css">
	.style1{font-size:16px};
	.body{font-family:Arial, Helvetica, sans-serif;}
	.con{padding:50px;}
	input[type=text],input[type=password],input[type=date],textarea{
		width:100%;
		padding:15px;
		margin:5px 0 22px 0;
		display:inline-table;
		background-color:#3CC;}
		div{padding:15px;
		border:1px solid #3C6;
		margin:bottom;}
		input[type=text]:focus,input[type=password]:focus,input[type=date]:focus{
			background-color:#636;}
		
    </style>
    </head>
	<body bgcolor="#00CC99">
	<div align="center" class="bu"> Welcome To Our Music World </div>

<table width="954" align="center" border="1" class="su">
  <tr>
    <td width="146" align="center"><a href="img-profile.php">Home</a></div></td>
    <td width="146" align="center">Regristation</div></td>
    <td width="146" align="center"><a href="select.php">Select</a></div></td>
	<td width="146" align="center"><a href="login.php">Log in</a></td>
	<td width="146" align="center"><a href="contact.php">Contact Us</a></td>
  </tr>
</table>

	<div class="re" align="center">User regristation</div>
	<form action="regitra.php" method="post" enctype="multipart/form-data" target="_self"><br>
	<label>Enter_Name:-</label>
	<input  name="Enter_Name" type="text"  maxlength="30" required="required"/><br/>
	<br><label>User_Name:-</label>
	<input name="User_Name" type="text" maxlength="30" required="required"/>
	<br/>
	<br><label>Password:-</label>
   <input name="Password" type="password" maxlength="15" id="Password" required="required"/>
	<br/>
	<br><label>Mobile_no:-</label>
	<input name="Mobile_no" type="text" maxlength="10" required/>
	<br/>
	<br><label>Gender:-</label>
	<input name="Gender" type="radio" value="m" required="required" checked="checked"/>
	  male
  <input name="Gender" type="radio" value="f" required="required"/>
	  female
	  <br />
	<br><label>Email:-</label>
	<input name="Email" type="text" accesskey="@email.com" required="required"/>
	<br/>
	 <br><label>Date_of_birth:-</label>
	<input name="Date_of_birth" type="date" required="required" />
	<br/>
	  <br><div class="re" align="center">
		 <input name="Submit" type="submit" class="bu" value="Submit"/>
	 <span class="style1"></span>
		   <input type="reset" class="bu" value="Reset" />
	  </div>
	</form>
	</body>
<?php 
	if(isset($_POST['Submit']))
	{
	
      $dbhost="localhost";
	  $dbname="music_world";
	  $dbusername="root";
	  $dbpassword="";
	  $msg="";
	  
	  $Enter_Name=$_POST['Enter_Name'];
	  $User_Name=$_POST['User_Name'];  
	  $Password=$_POST['Password'];
	  $Mobile_no=$_POST['Mobile_no'];
	  $Gender=$_POST['Gender'];
	  $Email=$_POST['Email'];
	  $Date_of_birth=$_POST['Date_of_birth'];
	  
	if(!empty($Enter_Name) || !empty($User_Name) || !empty($Password)|| !	empty($Mobile_no) || !empty($Gender) || !empty($Email) || !empty($Date_of_birth))
	 {		
	  $conn=new mysqli($host,$dbusername,$dbpassword, $dbname);
	    if(mysqli_connect_error())
		{
	  die('connection failed Error('. mysqli_connect_error().')'. mysqli_connect_error());
	  	}
	    else
		{
			$SELECT = "SELECT email from regristation where email = '$Email' ";
		 	$sql = "INSERT INTO `regristation` (`Id`, `User_Name`, `Password`, `Mobile_no`, `Gender`, `Email`, `Date_of_birth`) VALUES ('','$User_Name','$Password','$Mobile_no','$Gender', '$Email','$Date_of_birth')";
			 $stmt = $conn->query($SELECT);	    
			$rnum = $stmt->num_rows;
			if ($rnum==0) 
			{
				$conn->query($sql);
				echo $msg="Regristation successfully...";
			}
			else
			{
		 		echo $msg="Someone already regristation using this email";
			}
		 }
	}
	else{echo "All field are required";
	  die();}
	  
}
	  ?>
</html>