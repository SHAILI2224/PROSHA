<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
</body>
<?php 
session_start();
include('regristra.php');
$username=$_POST['username'];
$result = mysqli_query($con,"SELECT * FROM member WHERE username='$username'");
$num_rows = mysqli_num_rows($result);
if ($num_rows) {
 header("location: index.php?remarks=failed"); 
}else {
 $Enter_name=$_POST['Enter_name'];
 $User_name=$_POST['User_name'];
 $password=$_POST['password'];
  $Mobile_no=$_POST['Mobile_no'];
 $gender=$_POST['gender'];
 $email=$_POST['email'];
$date_of_birth=$_POST['date_of_birth'];
 if(mysqli_query($con,"INSERT INTO member(Enter_name, User_name, password ,Mobile_no, gender, email, date_of_birth)VALUES('$Enter_name', '$User_name','$password', '$Mobile_no', '$gender', '$email', '$date_of_birth')")){ 
 header("location: index.php?remarks=success");
 }else{
  $e=mysqli_error($con);
 header("location: index.php?remarks=error&value=$e");  
 }
}
?>
</html>