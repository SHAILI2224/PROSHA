<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Contect us</title>
<link href="feedback.css" rel="stylesheet" type="text/css" />
</head>
<body bgcolor="#FF99CC">
<div align="center" class="bu"> Welcome To Our Music World </div>

<table width="954" align="center" border="1" class="su">
  <tr>
    <td width="146" align="center"><a href="img-profile.php">Home</a></div></td>
    <td width="146" align="center"><a href="regitra.php">Regristation</a></div></td>
    <td width="146" align="center"><a href="select.php">Select</a></div></td>
	<td width="146" align="center"><a href="login.php">Log in</a></td>
	<td width="146" align="center">Contact Us</td>
  </tr>
</table>
<h3>Our contact:-This is project aboute Music Managment system.This is made by student because learn about.
<br />Give your feedback in hear.</h3> 
<form id="feedback" method="post" action="contact.php" class="form">
        	  <h3 style="color:#09F; font-size20px">Feedback Form</h3>
        	<div class="FeedBackForm" id="FeedBackForm">
                <label for="fname" id="f">User Name</label><br />
                <input type="text" name="User Name" id="fname" size="60"placeholder="Complete Name" required/><br />  
                <label for="Date" id="f">Date</label><br />
                <input type="Date" name="Date" id="faddress" size="60" placeholder="Date" required/><br />
                <label for="fmessage" id="f">Message</label><br />
           <textarea name="message" cols="37" rows="8" placeholder="Your Message" id="fmessage"></textarea>  
            </div> 	
            <div>
            	<input type="submit" value="Submit" id="sub"/>&nbsp;<input type="reset" value="Cancel" id="can"/>
            </div>
</form>

<a href="../Music World.php" target="thanks" target="_self">Thank you</a>
</body>

<?php 
	if(isset($_POST['Submit']))
	{
	
      $dbhost="localhost";
	  $dbname="music_world";
	  $dbusername="root";
	  $dbpassword="";
	  $msg="";
	  
	  $User_Name=$_POST['User_Name'];  
	  $Date=$_POST['Date'];
	  $message=$_POST['message'];
	  
	if(!empty($User_Name) || !empty($Date_of_birth) || !empty($message))
	 {		
	  $conn=new mysqli($host,$dbusername,$dbpassword, $dbname);
	    if(mysqli_connect_error())
		{
	  die('connection failed Error('. mysqli_connect_error().')'. mysqli_connect_error());
	  	}
	    else
		{
	    	$sql = "INSERT INTO `regristation` (`Id`, `User_Name`, `Date`, 'message') VALUES ('','$User_Name','$Date','$message')";
			$stmt = $conn->query($sql);	    
			$rnum = $stmt->num_rows;
			if ($rnum==0) 
			{
				$conn->query($sql);
				echo $msg="feedback successfully...";
			}
		 }
	}
	else{echo "All field are required";
	  die();}
}
?>
</html>