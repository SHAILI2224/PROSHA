<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>replay user</title>
</head>

<body>
 <div class="home_content">
    	<h2 class="header">Reply User Feedbacks</h2>	
        	<div class="form">
            	<div class="error"></div>
                <div class="success"></div>
                <form action="send.php" method="post">
                    <table>
                        <tr>
                            <td align="right">To:</td>
                            <td>
                              <input type="text" value="" size="79" readonly="readonly" name="name"/></td>
                        </tr>
                        <tr>
                            <td align="right">Email Address:</td>
                            <td><input type="text" value=""  readonly="readonly"size="79" name="email"/></td>
                        </tr>
                        <tr>
                            <td align="right">Original Message:</td>
                            <td>
                            <textarea rows="8" cols="60" readonly="readonly" style="max-height:200px; max-width:500px; min-height:200px; min-width:500px;"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td align="right">Your Message</td>
                            <td>
                                <textarea rows="11" cols="60" style="max-height:200px; max-width:500px; min-height:200px; min-width:500px;" name="adminmsg"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td><input type="submit"  value="Send"/>&nbsp;<input type="button" value="Back" onclick="window.location.href='Feedbacks.php'" /></td>
                        </tr>
                  </table>
	</form>
 </div>
 </div>
 <table align="center" bgcolor="#66CC66" border="1">
<tr>
<td align="center"><a href="ad.php">adhome</a></td>
<td align="center"><a href="tadsongs.php">admin addsongs</a></td>
</tr>
</table>
</body>
<?php
if(isset($_POST['Send']))
	{
      $dbhost="localhost";
	  $dbname="music_world";
	  $dbusername="root";
	  $dbpassword="";
	  $msg="";
	  
	  $To=$_POST['To'];
	  $Email=$_POST['Email'];  
	  $adminmsg=$_POST['adminmsg']; 
	if(!empty($To) || !empty($Email) || !empty($adminmsg))
	 {		
	  $conn=new mysqli($host,$dbusername,$dbpassword, $dbname);
	    if(mysqli_connect_error())
		{
	  die('connection failed Error('. mysqli_connect_error().')'. mysqli_connect_error());
	  	}
	    else
		{
			$SELECT = "SELECT email from replay user where email = '$Email' ";
		 	$sql = "INSERT INTO `reply user` (`To`, `Email`, `adminmsg`) VALUES ('','$TO','$Email','$adminmsg')";
			 $stmt = $conn->query($sql);	    
			$rnum = $stmt->num_rows;
			if ($rnum==0) 
			{
				$conn->query($sql);
				echo $msg="user replay successfully...";
			}
		 }
	}
	else{echo "All field are required";
	  die();}
	  
}
?>
</html>