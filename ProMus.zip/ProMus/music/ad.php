<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>admin </title>
</head>
<body>
<form action="ad.php" 
method="post" enctype="multipart/form-data" name="admin">
<div align="center">Admin add user/cancle</div>
<div align="center">
<label for="Name">Name</label>
  <input type="text" name="txtname" id="txtname" placeholder="Complete Name" size="39" reqyired/>
</div>
<div align="center">
<label for="password">Password</label>
<input type="text" name="txtpass"  placeholder="Password" size="39" required/>
</div>
<div align="center">
<input type="submit" value="Add User" id="button1" name="add"/>
<input type="reset" value="Cancel" id="button2"/>
</div>
</form>
</body>
<table align="center" bgcolor="#66CC66" border="1">
<tr>
<td align="center"><a href="tadsongs.php">admin addsongs</a></td>
<td align="center"><a href="replay user.php">adreplay user</a></td>
</tr></table>
<?php 
	if(isset($_POST['OK']))
	{
	
      $dbhost="localhost";
	  $dbname="music_world";
	  $dbusername="root";
	  $dbpassword="";
	  $msg="";
	  
	  $Enter_Name=$_POST['Enter_Name'];
	  $Password=$_POST['Password'];
	  
	if(!empty($Enter_Name) || !empty($Password))
	 {		
	  $conn=new mysqli($host,$dbusername,$dbpassword, $dbname);
	    if(mysqli_connect_error())
		{
	  die('connection failed Error('. mysqli_connect_error().')'. mysqli_connect_error());
	  	}
	    else
		{
		 $sql = "INSERT INTO `login` (`Id`, `User_Name`, `Password`) VALUES ('','xyz','xyz')";
		 $stmt = $conn->query($SELECT);	    
	     $rnum = $stmt->num_rows;
			if ($rnum==0) 
			{
				$conn->query($sql);
				echo $msg="login successfully...";
			}
			else
			{
		 		echo $msg="Someone incorrect";
			}
		 }
	}
	else{echo "All field are required";
	  die();}  
}?>
</html>