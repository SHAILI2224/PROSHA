<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Select</title>
<link href="playlist.css" rel="stylesheet" type="text/css" />
</head>
<body background="Screenshot_2022-01-04-21-22-09-348_com.miui.home~2.jpg">

<div align="center" class="playlist"> Welcome To Our Music World </div>

<table width="954" align="center" border="1" class="playlist">
  <tr>
    <td width="146" align="center"><a href="img-profile.php">Home</a></div></td>
    <td width="146" align="center"><a href="regitra.php">Regristation</a></div></td>
    <td width="146" align="center">Select</div></td>
	<td width="146" align="center"><a href="login.php">Log in</a></td>
	<td width="146" align="center"><a href="contact.php">Contact Us</a></td>
  </tr>
</table>

<div style="background-color:#CC6600">
<a href="Kalimba.mp3" target="_self" class="he">Kala</a>
</div>
</body>
</html>