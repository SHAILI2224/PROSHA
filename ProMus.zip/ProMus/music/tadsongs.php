<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>tadsongs</title>
</head>

<body>
<h2 class="header">Add Song</h2>
        <div class="success"></div>
			<form id="form" method="post" name="form" enctype="multipart/form-data" action="AdminAddSong.php" target="uploadframe">	
                <div>
                    <iframe src="" id="uploadframe" name="uploadframe" 
                    style="width:0px; height:0px; border:0px;"></iframe>
                </div>     
            	<div>
               	  <label for="Category">Song Category</label>
                	<input type="text" value="" name="txtcat" id="txtcat" size="39" readonly="readonly"/>
                </div>
              <div>
                	<label for="Category">Song Album</label> 
                    
               		<input type="text" size="39" value="" readonly="readonly" />
                </div>
                <div>
               	  <label for="Singer">Album Singer</label>
                	<input type="text" name="txtsinger" id="txtsinger" value=""  readonly="readonly" size="39"/>
              </div>
                <div>
                	<label for="Singer">Album Writer</label>
                	<input type="text" name="txtwriter" id="txtwriter" value=""  readonly="readonly" size="39"/>
                </div>
                <div>
                	<label for="Description">Description</label>
                    <textarea rows="8" cols="50" placeholder="MP3 Description" name="txtdesc" id="txtdesc"></textarea>
                </div>
              <div>
                	<label for="Category">Song File</label>
               		<input type="file" name="txtsong" id="txtsong"/>
                </div>
                <div>
               	  <input type="submit" value="Add Song" id="button1"/>
                    <input type="button" value="Back" id="button2" onClick="window.location.href='AdminViewAlbums.php'"/>
              </div>
            </form>
<table align="center" bgcolor="#66CC66" border="1">
<tr>
<td align="center"><a href="ad.php">adhome</a></td>
<td align="center"><a href="replay user.php">adreplay user</a></td>
</tr></table>
</body>
<?php
$con=mysqli_connect("localhost","root","","music_world");
if(mysqli_connect_error())
{
	echo "failed to connect to mysql:".mysqli_connect_error();	
}
$sql=("select * from tblsongs");
$result = $con->query($sql);

//print_r($result);exit;
while($row = $result->fetch_assoc())
{
	echo "<h1>".$row['songcat']."</h1>";
	echo "<br/>";
	echo "<h1>".$row['songalbum']."</h1>";
	echo "<br/>";
	echo "<h1>".$row['songsinger']."</h1>";
	echo "<br/>";
	echo "<h1>".$row['songdesc']."</h1>";
	echo "<br/>";
	echo "<h1>".$row['songfile']."</h1>";
	echo "<br/>";
	echo "<h1>".$row['songwriter']."</h1>";
	echo "<br/>";
	echo "<h1>".$row['songpoint']."</h1>";
}
?>
</html>