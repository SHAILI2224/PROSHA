<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Img-profile</title>
<link href="sha.css" rel="stylesheet" type="text/css" />

</head>

<body bgcolor="#CC3399">
<div align="center" class="sha"> Welcome To Our Music World </div>

<table width="954" align="center" border="1" class="re">
  <tr>
    <td width="146" align="center">Home</div></td>
    <td width="146" align="center"><a href="regitra.php">Regristation</a></div></td>
    <td width="146" align="center"><a href="select.php">Select</a></div></td>
	<td width="146" align="center"><a href="login.php">Log in</a></td>
	<td width="146" align="center"><a href="contact.php">Contact Us</a></td>
  </tr>
</table>


<div align="right">
  <a href="" class="para">Profile</a>
</div>
<div align="left" class="sha"><img src="IMG-20211209-WA0002.jpg" alt="abcd" width="592" height="606" border="4" longdesc="file:///C|/wamp/www/Project/music/IMG-20211209-WA0002.jpg"/>
</div>
</body>
</html>