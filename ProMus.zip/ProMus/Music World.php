<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Music_World</title>
<link href="music/sha.css" rel="stylesheet" type="text/css" />
</head>
<body bgcolor="#FFCCFF">
<link href="music/sha.css" rel="stylesheet" type="text/css" />
<div align="center" class="ha"><h1> Welcome To Our Music World </h1></div>
<form action="music/mus.php" method="post" name="form1" target="_blank" class="fr" id="form1">
<table width="954" align="center" border="1" class="re">
  <tr>
    <td width="146" align="center"><a href="music/img-profile.php"><b>Home</b></a></div></td>
    <td width="146" align="center"><a href="music/regitra.php"><b>Regristation</b></a></div></td>
    <td width="146" align="center"><a href="music/select.php">Select</a></div></td>
	<td width="146" align="center"><a href="music/login.php">Log in</a></td>
	<td width="146" align="center"><a href="music/contact.php">Contact Us</a></td>
  </tr>
</table>
</form>
<div align="center" style="background-color:#99FF00"><img src="music/Screenshot_20211225-143806.jpeg" class="im" /></div>
<p class="para">The aim of this project is the development of a sample centralized Relational Music Management System.
</p>
<p class="para">This application has to store information of customers and artists with their products.
</p>
<p class="para">In this context the functionality is to update, remove and insert records for the different entities.</p>
<p class="para">These wishes include finding the right album and ordering this album.</p>
<p class="para">This project team decided to implement the core functionality first and later to attach additional functions.</p>
<a href="music/ad.php">Admin login</a>
</body>
</html>